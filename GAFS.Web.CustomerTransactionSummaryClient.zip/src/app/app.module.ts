import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SearchComponent } from './Components/search/search.component';
import { ResultsComponent } from './Components/results/results.component';
import { ContractComponent } from './Components/contract/contract.component';
import { AssetComponent } from './Components/asset/asset.component';
import { PaymentComponent } from './Components/payment/payment.component';
import { UsageComponent } from './Components/usage/usage.component';
import {Routing} from './app.routing';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {YesNo} from './Pipes/YesNo';

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    ResultsComponent,
    ContractComponent,
    AssetComponent,
    PaymentComponent,
    UsageComponent,
    YesNo
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    Routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
