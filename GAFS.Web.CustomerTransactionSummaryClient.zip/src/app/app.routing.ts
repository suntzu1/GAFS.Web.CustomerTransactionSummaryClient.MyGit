import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchComponent } from './Components/search/search.component';
import {ResultsComponent } from '../app/Components/results/results.component';

const appRoutes: Routes = [
    { path: '', component: SearchComponent, pathMatch: 'full' },
    { path: 'search', component: SearchComponent, pathMatch: 'full' },
    { path: 'results', component: ResultsComponent, pathMatch: 'full' },
];

export const Routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
