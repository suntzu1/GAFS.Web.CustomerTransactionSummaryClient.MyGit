import { Component, OnInit } from '@angular/core';
import { Router } from '../../../../node_modules/@angular/router';

@Component({
  selector: 'cts-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css']
})
export class ResultsComponent implements OnInit {
  tab = 0;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  gobacktosearch() {
    this.router.navigateByUrl('/search');
  }
}
