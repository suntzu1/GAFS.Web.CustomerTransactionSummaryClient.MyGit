import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cts-usage',
  templateUrl: './usage.component.html',
  styleUrls: ['./usage.component.css']
})
export class UsageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
