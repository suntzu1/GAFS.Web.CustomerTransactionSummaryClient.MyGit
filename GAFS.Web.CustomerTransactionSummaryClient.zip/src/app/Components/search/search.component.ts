import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import {} from '../../../app/Components/results/results.component'

@Component({
  selector: 'cts-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  tab = 0;
  constructor(private router: Router) { }

  ngOnInit() {
  }

  onappidsearchclick() {
    this.router.navigateByUrl('/results');
  }
}
