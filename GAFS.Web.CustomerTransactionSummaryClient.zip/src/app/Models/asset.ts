import { Address } from './address';

export interface Asset {
AssetID: number;
Manufacturer: string;
Model: string;
SerialNumber: string;
VendorMachineID: string;
AssetAddress: Address;
PPTX: string;
SalesTax: number;
FinancedAmt: number;
AgreementOveragesBilledOn: string;
ContractActive: boolean;
}
