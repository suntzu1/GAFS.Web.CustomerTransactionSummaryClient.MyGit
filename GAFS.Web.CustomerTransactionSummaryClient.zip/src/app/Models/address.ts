export class Address {
    StreetAddress: string;
    Address2: string;
    City: string;
    State: string;
    Zip: string;
    Contact: string;
}
